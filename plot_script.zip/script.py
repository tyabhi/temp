#!/usr/bin/env python
# coding: utf-8

# In[37]:


from matplotlib import pyplot as plt
import pandas as pd


# In[38]:


data = pd.read_csv('/Users/abhishek/Downloads/RS_Session_253_AU748_II.csv')
data.tail()


# In[39]:


data_x = data['States'][0:35]
data_y1 = data['2019-20 - No. of Projects (Women)'][0:35]
data_y2 = data['2019-20 - Margin Money Utilized Rs. in Lakh'][0:35]


# In[40]:


fig = plt.figure(figsize=(18,5))
plt.scatter(data_x,data_y1)
plt.scatter(data_x,data_y2)
fig.autofmt_xdate(rotation=40)
plt.legend(['No. of Projects (women)','Margin Money utilized in Rs Lakh'])
plt.title('2019-20 State wise subsidy disbursed to women under PMEGP scheme')
plt.xlabel('States')
plt.ylabel('Rs in Lakh & no. of women')
plt.show()


# In[41]:


plt.boxplot(data_y1)
plt.xlabel('Projects (Women) ')
plt.ylabel('Frequency Distribution')
plt.title('Boxplot of No. of Projects (Women)')
plt.show()
plt.xlabel('Margin Money utilized n')
plt.ylabel('Frequency Distribution')
plt.title('Boxplot of Margin Money Utilized in Rs Lakh')
plt.boxplot(data_y2)
plt.show()


# In[42]:


fig= plt.figure(figsize=(18,5))
plt.plot(data_x,data_y1)
plt.plot(data_x,data_y2)
fig.autofmt_xdate(rotation=40)
plt.legend(['No. of Projects (women)','Margin Money utilized in Rs Lakh'])
plt.title('2019-20 State wise subsidy disbursed to women under PMEGP scheme')
plt.xlabel('States')
plt.ylabel('Rs in Lakh & no. of women')
plt.show()





